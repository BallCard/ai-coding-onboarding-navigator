import { motion } from 'motion/react';
import { 
  Code2, 
  Bug, 
  FileSearch, 
  Terminal, 
  Clock, 
  Target,
  ArrowRight,
  ShieldCheck,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { Link } from 'react-router-dom';

const TASKS = [
  {
    id: 'web-tool',
    title: '生成一个网页实用工具',
    desc: '让 AI 帮你写一个简单的汇率转换器或 Todo List，并直接在浏览器运行。',
    time: '15 min',
    difficulty: 'Easy',
    icon: Code2,
    color: 'bg-emerald-50 text-emerald-600',
    tags: ['React/HTML', 'Frontend']
  },
  {
    id: 'fix-bug',
    title: '修复一个现有 Bug',
    desc: '粘贴一段有报错的代码，让 AI 诊断并自动修复。',
    time: '10 min',
    difficulty: 'Medium',
    icon: Bug,
    color: 'bg-red-50 text-red-600',
    tags: ['Debugging', 'Logic']
  },
  {
    id: 'explain-code',
    title: '解释陌生代码库',
    desc: '让 AI 概括一个 GitHub 项目的结构，并解释核心逻辑。',
    time: '20 min',
    difficulty: 'Easy',
    icon: FileSearch,
    color: 'bg-blue-50 text-blue-600',
    tags: ['Documentation', 'Learning']
  },
  {
    id: 'script-tool',
    title: '整理自动化脚本',
    desc: '比如：批量重命名文件、爬取简单动态网页数据。',
    time: '15 min',
    difficulty: 'Medium',
    icon: Terminal,
    color: 'bg-amber-50 text-amber-600',
    tags: ['Python/JS', 'Utility']
  }
];

export default function FirstTask() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-7xl mx-auto px-6 py-20"
    >
      <header className="mb-24">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-[2px] bg-emerald-500" />
          <span className="tertiary-text text-emerald-600 font-black">Execution Phase</span>
        </div>
        <h1 className="text-4xl font-extrabold tracking-tight mb-4">第一次 AI 编程实践</h1>
        <p className="text-zinc-500 max-w-2xl leading-relaxed font-medium">不要只是安装，选一个任务跑通它。这是建立信心的关键。我们为你筛选了四个适合校内开发者入门的切入点。</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
        {TASKS.map((task, idx) => (
          <motion.div 
            key={task.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="group relative bg-white structure-border rounded-[32px] overflow-hidden hover:border-zinc-300 transition-all duration-300 hover:shadow-[0_30px_70px_-20px_rgba(0,0,0,0.1)]"
          >
            <div className="p-10 flex flex-col h-full">
              <div className="flex items-center justify-between mb-8">
                <div className={`p-4 rounded-2xl ${task.color} border border-current opacity-20`} />
                <div className={`p-4 rounded-2xl ${task.color} border border-current absolute`}>
                  <task.icon size={24} />
                </div>
                <div className="flex gap-2">
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-50 border border-zinc-100 rounded-lg text-[10px] font-black uppercase tracking-widest text-zinc-400">
                    <Clock size={12} /> {task.time}
                  </div>
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-50 border border-zinc-100 rounded-lg text-[10px] font-black uppercase tracking-widest text-zinc-400">
                    <Target size={12} /> {task.difficulty}
                  </div>
                </div>
              </div>

              <h3 className="text-2xl font-bold tracking-tight mb-4 group-hover:text-zinc-600 transition-colors">{task.title}</h3>
              <p className="text-[14px] text-zinc-500 leading-relaxed mb-10 font-medium">
                {task.desc}
              </p>

              <div className="flex flex-wrap gap-2 mb-10">
                {task.tags.map(tag => (
                  <span key={tag} className="text-[9px] font-black uppercase tracking-[0.2em] bg-zinc-50 text-zinc-500 border border-zinc-100 px-2.5 py-1 rounded-md">
                    {tag}
                  </span>
                ))}
              </div>

              <div className="mt-auto pt-8 border-t border-zinc-100 flex items-center justify-between">
                <button className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-widest text-zinc-900 group/btn transition-colors hover:text-zinc-600">
                  开始实战 <ArrowRight size={14} className="transition-transform group-hover/btn:translate-x-1" />
                </button>
                <div className="flex items-center gap-1 text-emerald-500 tertiary-text font-black">
                   <Sparkles size={12} />
                   Popular
                </div>
              </div>
            </div>
            
            {/* Visual background hint */}
            <div className="absolute -right-16 -bottom-16 opacity-[0.03] scale-150 rotate-12 transition-transform group-hover:rotate-[0deg] group-hover:scale-[1.7] pointer-events-none">
               <task.icon size={240} />
            </div>
          </motion.div>
        ))}
      </div>

      {/* Success Standard Banner */}
      <div className="mt-32 p-16 rounded-[48px] bg-white structure-border text-center relative overflow-hidden shadow-2xl shadow-zinc-200/50">
        <div className="absolute inset-0 technical-grid opacity-5 pointer-events-none" />
        <div className="relative z-10">
          <h2 className="text-3xl font-extrabold tracking-tight mb-4">如何判断我“跑通了”？</h2>
          <p className="tertiary-text mb-16">Metrics for successful implementation</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-16 max-w-5xl mx-auto">
            {[
              { t: '产出物可运行', d: 'AI 生成的代码或修复的结果能在本地成功运行或构建。' },
              { t: '理解过程', d: '你能复述出 AI 是如何根据你的自然语言提示词找到解决路径的。' },
              { t: '掌握工具指令', d: '能熟练使用 /fix, /explain, /new 等基础 AI 协作指令。' }
            ].map(item => (
              <div key={item.t} className="space-y-6">
                <div className="w-12 h-12 rounded-2xl bg-zinc-900 text-white flex items-center justify-center mx-auto shadow-xl">
                   <ShieldCheck size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-3 tracking-tight">{item.t}</h4>
                  <p className="text-sm text-zinc-500 leading-relaxed font-medium">{item.d}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-20 flex flex-col md:flex-row items-center justify-center gap-6">
             <Link to="/" className="h-12 px-8 rounded-xl bg-zinc-900 text-white flex items-center justify-center text-[11px] font-bold uppercase tracking-widest hover:scale-105 transition-all shadow-xl shadow-zinc-200">
               回主页路线图
             </Link>
             <button className="flex items-center gap-2 tertiary-text font-black text-zinc-400 hover:text-zinc-900 transition-colors">
               我还需要更多案例 <ChevronRight size={14} />
             </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
