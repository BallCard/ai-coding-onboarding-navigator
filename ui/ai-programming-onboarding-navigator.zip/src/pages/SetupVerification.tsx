import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Monitor, 
  Smartphone, 
  CheckCircle2, 
  Circle, 
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  Terminal,
  AlertCircle
} from 'lucide-react';

export default function SetupVerification() {
  const [os, setOs] = useState<'windows' | 'macos'>('windows');

  const steps = [
    {
      id: 'precheck',
      title: '环境预检',
      content: {
        windows: '建议使用 PowerShell 7+ 或 WSL2。打开终端并输入命令查看你的系统版本。',
        macos: 'macOS 用户务必安装 Homebrew。它是所有后续开发工具的基石。'
      },
      command: os === 'windows' ? '$PSVersionTable.PSVersion' : 'brew --version'
    },
    {
      id: 'nodejs',
      title: 'Node.js 核心栈',
      content: {
        windows: '千万不要直接去官网下 .msi！请使用 nvm-windows 管理版本，防止以后切换项目时权限乱掉。',
        macos: '使用 brew install nvm，然后在配置文件中 source 即可。'
      },
      link: 'https://github.com/coreybutler/nvm-windows'
    },
    {
      id: 'install-cmd',
      title: '执行安装指令',
      content: {
        windows: '确保你已经以“管理员身份”启动了终端，否则 node_modules 写入会频繁报错。',
        macos: '直接在终端执行。如果报错权限，切记不要盲目 sudo。'
      },
      command: 'npm install -g @anthropic-ai/claude-code'
    },
    {
      id: 'verify',
      title: '首次握手验证',
      content: {
        windows: '输入 claude 查看版本。如果报错“无法识别命令”，请检查环境变量 PATH。',
        macos: '输入 claude 查看版本。如果报错 command not found，检查 ~/.zshrc 环境配置。'
      },
      command: 'claude --version'
    }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-7xl mx-auto px-6 py-32"
    >
      <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-12 mb-32 border-b border-clay/30 pb-16">
        <div>
          <div className="flex items-center gap-4 mb-6">
             <div className="w-12 h-[1px] bg-ink" />
             <span className="tertiary-text">03 / Implementation</span>
          </div>
          <h1 className="text-5xl font-serif tracking-tight text-ink">环境原子配置</h1>
        </div>

        <div className="flex bg-oat/40 p-2 rounded-full border border-clay/40 shadow-inner">
          <button 
            onClick={() => setOs('windows')}
            className={`flex items-center gap-3 px-8 py-3.5 rounded-full text-[11px] font-black uppercase tracking-[0.2em] transition-all ${os === 'windows' ? 'bg-ink text-paper shadow-xl' : 'text-sage/50 hover:text-ink'}`}
          >
            <Monitor size={14} /> Desktop (Win)
          </button>
          <button 
            onClick={() => setOs('macos')}
            className={`flex items-center gap-3 px-8 py-3.5 rounded-full text-[11px] font-black uppercase tracking-[0.2em] transition-all ${os === 'macos' ? 'bg-ink text-paper shadow-xl' : 'text-sage/50 hover:text-ink'}`}
          >
            <Smartphone size={14} /> Desktop (Mac)
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-24">
        {/* Main Steps Grid */}
        <div className="lg:col-span-8 space-y-32">
          {steps.map((step, idx) => (
            <div key={step.id} className="relative group">
              <div className="flex flex-col md:flex-row gap-16">
                <div className="flex-shrink-0">
                   <div className="text-6xl font-serif italic text-clay/40 group-hover:text-sage/30 transition-colors leading-none tracking-tighter">
                     0{idx + 1}
                   </div>
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-6 mb-8">
                    <h3 className="text-3xl font-serif font-bold tracking-tight text-ink">{step.title}</h3>
                    <div className="h-px flex-1 bg-clay/20" />
                  </div>
                  
                  <p className="text-[17px] text-sage/70 leading-relaxed mb-10 max-w-2xl font-medium">
                    {os === 'windows' ? step.content.windows : step.content.macos}
                  </p>

                  {step.command && (
                    <div className="terminal-box mb-10 group/terminal relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
                      <div className="flex items-center gap-2 mb-6 opacity-20">
                        <div className="w-1.5 h-1.5 rounded-full bg-paper" />
                        <div className="w-1.5 h-1.5 rounded-full bg-paper" />
                        <div className="w-1.5 h-1.5 rounded-full bg-paper" />
                      </div>
                      <code className="block flex-1 text-paper/90 select-all font-mono text-[14px] leading-relaxed">$ {step.command}</code>
                      <button className="absolute right-8 bottom-6 tertiary-text !text-paper/30 hover:!text-paper/90 transition-all">
                        CLIPBOARD • COPY
                      </button>
                    </div>
                  )}

                  <div className="flex items-center gap-10">
                    {step.link && (
                      <a href={step.link} target="_blank" rel="noreferrer" className="link-claude">
                        Reference Dossier <ExternalLink size={14} />
                      </a>
                    )}
                    <button className="flex items-center gap-2 tertiary-text hover:text-sage/90 transition-colors">
                      <AlertCircle size={14} /> Error Protocol
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Sidebar Context */}
        <div className="lg:border-l lg:border-zinc-200 lg:pl-10 space-y-12">
          <div className="space-y-4">
            <h4 className="tertiary-text">校内网适配计划</h4>
            <p className="text-xs text-zinc-500 leading-relaxed">
              针对校内网环境，我们建议优先配置 <b>registry.npmmirror.com</b> 镜像。同时在 VS Code 内设置代理以保证 Copilot 续写流畅。
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="tertiary-text">常见错误日志</h4>
            <div className="space-y-3">
              {[
                { err: 'ETIMEDOUT', res: '切换网络或使用全局代理' },
                { err: 'EPERM', res: '右键以管理员运行终端' },
                { err: 'NODE_VERSION', res: '使用 nvm 升级至 18+' }
              ].map(log => (
                <div key={log.err} className="bg-zinc-50 structure-border p-3 rounded-xl">
                  <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">{log.err}</div>
                  <div className="text-[11px] font-bold">{log.res}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
