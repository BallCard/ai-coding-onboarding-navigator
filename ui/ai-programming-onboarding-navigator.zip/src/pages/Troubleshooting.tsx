import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useSearchParams } from 'react-router-dom';
import { TROUBLESHOOTING_DATA } from '../constants';
import { 
  Search, 
  Filter, 
  AlertTriangle, 
  HelpCircle, 
  ExternalLink,
  Tag,
  Monitor,
  CheckCircle2
} from 'lucide-react';

const CATEGORIES = [
  { id: 'all', label: '全部' },
  { id: 'network', label: '网络 / 代理' },
  { id: 'auth', label: '登录 / 授权' },
  { id: 'env', label: '环境变量' },
  { id: 'npm', label: 'npm / Node' },
  { id: 'permission', label: '权限' }
];

export default function Troubleshooting() {
  const [searchParams] = useSearchParams();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState(searchParams.get('category') || 'all');

  useEffect(() => {
    const cat = searchParams.get('category');
    if (cat) setCategory(cat);
  }, [searchParams]);

  const filtered = TROUBLESHOOTING_DATA.filter(item => {
    const matchesSearch = item.symptom.toLowerCase().includes(search.toLowerCase()) || 
                          item.cause.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = category === 'all' || item.category === category;
    return matchesSearch && matchesCategory;
  });

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-7xl mx-auto px-6 py-24"
    >
      <header className="mb-20 max-w-2xl">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-[1px] bg-sage" />
          <span className="tertiary-text">Response Engineering</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-serif tracking-tight mb-6 text-ink">故障排除与环境诊断</h1>
        <p className="text-sage/80 leading-relaxed font-medium">
          不必在搜索引擎里大海捞针。这里汇总了中国校园网络环境下常见的技术龃龉，旨在通过精确的指令引导，帮你跨越最后 10% 的上手障碍。
        </p>
      </header>

      {/* Control Panel */}
      <div className="flex flex-col lg:flex-row gap-6 mb-24">
        <div className="flex-1 relative group">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-clay group-focus-within:text-ink transition-colors" size={20} />
          <input 
            type="text" 
            placeholder="搜索关键词 (如: ETIMEDOUT, 403, PowerShell...)"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-16 pr-6 py-5 bg-white border border-clay/40 rounded-2xl focus:outline-none focus:ring-4 focus:ring-clay/10 focus:border-clay transition-all text-sm font-medium shadow-sm"
          />
        </div>
        <div className="flex bg-oat/30 p-1.5 rounded-2xl border border-clay/30 overflow-x-auto no-scrollbar shadow-sm">
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => setCategory(cat.id)}
              className={`whitespace-nowrap px-6 py-3 rounded-xl text-[11px] font-bold uppercase tracking-widest transition-all ${category === cat.id ? 'bg-ink text-paper shadow-xl' : 'text-sage/60 hover:text-ink'}`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Data Visual Grid */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {filtered.map((item, idx) => (
            <motion.div 
              key={item.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="group step-card flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-10">
                  <div className={`px-2.5 py-1 rounded-md text-[9px] font-black uppercase tracking-widest shadow-sm ${
                    item.category === 'network' ? 'bg-sage text-paper' :
                    item.category === 'npm' ? 'bg-[#9d4444] text-paper' :
                    'bg-ink text-paper'
                  }`}>
                    {item.category}
                  </div>
                  <div className="flex gap-2">
                    <span className="tertiary-text text-[9px] opacity-40">{item.os} 系统推荐</span>
                  </div>
                </div>

                <h3 className="text-xl font-serif font-bold tracking-tight mb-6 leading-tight text-ink group-hover:opacity-60 transition-opacity">
                  {item.symptom}
                </h3>
                
                <div className="space-y-8">
                  <div>
                    <h4 className="tertiary-text mb-4">根因分析</h4>
                    <p className="text-[14px] text-sage/70 leading-relaxed font-medium">
                      {item.cause}
                    </p>
                  </div>

                  <div>
                    <h4 className="tertiary-text mb-4">执行链路</h4>
                    <div className="space-y-2">
                      {item.solution.map((step, sIdx) => (
                        <div key={sIdx} className="terminal-box py-3 px-4 text-xs">
                          <span className="opacity-30 mr-2">$</span>{step}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-12 pt-8 border-t border-clay/30 flex items-center justify-between">
                <div className="flex items-center gap-2 tertiary-text text-[9px]">
                  <ShieldCheck size={12} className="text-clay" />
                  验证来源: {item.provenance}
                </div>
                <button className="link-claude">
                  诊断详情 <ArrowRight size={14} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="py-40 text-center bg-white border border-clay/30 rounded-[40px] shadow-sm">
          <HelpCircle size={48} className="mx-auto text-clay/30 mb-8" />
          <h3 className="text-xl font-serif font-bold mb-3 tracking-tight text-ink/60">未匹配到相关案例</h3>
          <p className="text-sm text-sage/50 font-medium">试着更换关键词，或查阅底层的官方文档。</p>
        </div>
      )}
    </motion.div>
  );
}
