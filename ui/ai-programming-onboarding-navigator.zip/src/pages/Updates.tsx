import { motion } from 'motion/react';
import { 
  History, 
  ExternalLink, 
  ShieldCheck, 
  BookOpen,
  Calendar,
  CheckCircle2,
  ChevronRight,
  Send
} from 'lucide-react';

const UPDATES = [
  {
    date: '2026-05-01',
    title: 'Claude Code 预览权限定位更新',
    desc: '更新了关于国内 IP 直接访问 API 的最新防火墙动态及代理配置建议。重点修正了关于 .anthropicrc 的自动加载序列优先级。',
    source: 'official',
    link: 'https://anthropic.com'
  },
  {
    date: '2026-04-28',
    title: 'nvm-windows 与 PowerShell 7 兼容性笔记',
    desc: '新增了 Windows 用户常见的权限报错解决方案。针对 zsh 别名在 WSL2 环境下的穿透现象进行了归档。',
    source: 'personal',
    link: '#'
  },
  {
    date: '2026-04-20',
    title: 'GitHub Copilot 学生包申请策略',
    desc: '针对中国高校学生证审核变严的情况，补充了学信网验证截图的提交技巧。建议开发者优先使用 edu.cn 邮箱通过 SSO 链路。',
    source: 'community',
    link: '#'
  }
];

const SOURCE_TYPES = [
  { id: 'official', label: 'Official', desc: '官方文档指引', color: 'text-emerald-500 bg-emerald-50 border-emerald-100' },
  { id: 'community', label: 'Community', desc: '社区实践共识', color: 'text-blue-500 bg-blue-50 border-blue-100' },
  { id: 'personal', label: 'Personal Note', desc: '作者实操归档', color: 'text-amber-500 bg-amber-50 border-amber-100' }
];

export default function Updates() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-7xl mx-auto px-10 py-48"
    >
      <header className="mb-48 max-w-3xl">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-[1px] bg-sage" />
          <span className="tertiary-text !tracking-[0.3em] !text-sage">Knowledge Integrity</span>
        </div>
        <h1 className="text-6xl font-serif tracking-tighter mb-8 text-ink leading-none">情报流动：<br/><span className="opacity-40 italic">系统的熵减</span></h1>
        <div className="flex items-center gap-4">
           <div className="p-2 rounded-full bg-oat border border-clay/30">
              <History size={16} className="text-sage" />
           </div>
           <p className="text-lg text-sage/60 font-serif italic font-medium">
             本站最后维护于 2026年5月4日 07:06 UTC
           </p>
        </div>
      </header>

      {/* Trust System */}
      <section className="mb-64">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-12 mb-24 border-b border-clay/30 pb-16">
          <div className="flex items-center gap-10">
            <div className="w-24 h-24 rounded-[40px] bg-ink text-paper flex items-center justify-center shadow-2xl relative">
              <div className="absolute inset-2 border border-paper/10 rounded-[32px]" />
              <ShieldCheck size={40} />
            </div>
            <div>
              <h2 className="text-4xl font-serif font-bold tracking-tight text-ink mb-2 italic">验证体系</h2>
              <p className="text-lg text-sage/50 font-medium font-serif italic">我们如何确保你看到的每一个字都是可靠的</p>
            </div>
          </div>
          <button className="btn-claude h-12 px-8 text-[10px]">
             Audit Standars <ChevronRight size={14} />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          {SOURCE_TYPES.map(type => (
            <div key={type.id} className="step-card group relative overflow-hidden">
               <div className="absolute top-0 right-0 w-32 h-32 bg-sage/5 rounded-full blur-[60px] translate-x-1/2 -translate-y-1/2" />
               <div className="relative z-10">
                  <div className={`tertiary-text !text-ink px-4 py-1.5 rounded-full inline-block mb-12 border border-clay/50 bg-paper transition-all group-hover:bg-ink group-hover:text-paper`}>
                    {type.label}
                  </div>
                  <h4 className="font-serif font-bold text-2xl mb-8 tracking-tight text-ink italic">{type.desc}</h4>
                  <p className="text-[15px] text-sage/70 leading-relaxed font-medium">
                    所有标有此类型的条目，您都可以在条目详情中点击来源链接查看原始信息出处。我们严格遵循 Zettelkasten 笔记法的原子性原则。
                  </p>
               </div>
            </div>
          ))}
        </div>
      </section>

      {/* Change Log */}
      <section className="relative">
        <div className="flex items-center gap-8 mb-32">
          <div className="w-20 h-20 rounded-[32px] bg-oat border border-clay/40 text-sage flex items-center justify-center shadow-inner">
            <BookOpen size={36} />
          </div>
          <h2 className="text-5xl font-serif font-bold tracking-tight text-ink italic">实时流水记录</h2>
        </div>

        <div className="space-y-0 relative">
          <div className="absolute left-[63px] top-6 bottom-6 w-px bg-clay/30" />
          
          {UPDATES.map((update, idx) => (
            <motion.div 
              key={idx} 
              initial={{ opacity: 0, x: -10 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex gap-24 group relative py-20 first:pt-0"
            >
              <div className="flex-shrink-0 relative z-10">
                <div className="w-32 flex justify-center pt-4">
                  <div className="w-14 h-14 rounded-full bg-paper border border-clay flex items-center justify-center transition-all duration-700 group-hover:bg-ink group-hover:border-ink shadow-sm relative overflow-hidden">
                    <CheckCircle2 size={24} className="text-clay group-hover:text-paper" />
                    <div className="absolute inset-0 bg-gradient-to-tr from-white/10 to-transparent" />
                  </div>
                </div>
              </div>
              
              <div className="flex-1 step-card group-hover:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.06)]">
                <div className="flex flex-col md:flex-row md:items-center gap-6 mb-10">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2 tertiary-text !text-sage/40">
                      <Calendar size={14} /> {update.date}
                    </div>
                    <div className={`px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-[0.2em] ${
                      update.source === 'official' ? 'bg-sage text-paper' :
                      update.source === 'community' ? 'bg-ink text-paper' :
                      'bg-oat text-sage border border-clay/50'
                    }`}>
                      {update.source}
                    </div>
                  </div>
                </div>
                <h3 className="text-4xl font-serif font-bold mb-8 tracking-tight text-ink group-hover:opacity-60 transition-opacity leading-[1.1] max-w-2xl">{update.title}</h3>
                <p className="text-[18px] text-sage/70 leading-relaxed mb-12 font-medium max-w-3xl font-serif italic border-l-2 border-clay/30 pl-8">
                  {update.desc}
                </p>
                {update.link !== '#' && (
                  <a href={update.link} target="_blank" rel="noreferrer" className="link-claude text-sm">
                    Access Dossier <ExternalLink size={16} />
                  </a>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Subscription Card */}
      <div className="mt-64 p-32 rounded-[80px] bg-ink text-paper relative overflow-hidden shadow-2xl">
        <div className="absolute inset-0 technical-grid opacity-[0.03] pointer-events-none" />
        <div className="absolute top-0 right-0 w-[1000px] h-[1000px] bg-clay/5 rounded-full blur-[180px] -translate-y-1/2 translate-x-1/4" />
        
        <div className="relative z-10 max-w-3xl">
          <Send className="text-clay/40 mb-12" size={64} />
          <h2 className="text-6xl font-serif font-bold tracking-tighter mb-10 italic leading-none opacity-90">工具在进化，<br/>环境在流动。</h2>
          <p className="text-paper/40 text-[20px] leading-relaxed mb-16 font-serif italic max-w-2xl border-l border-paper/10 pl-10">
            校内适配方案几乎每周都会迭代。留下你的联系方式，我们只在出现“必须要知道的系统补丁”或“重大网络动态”时才会打扰你。
          </p>
          <div className="flex flex-col lg:flex-row gap-6 max-w-xl">
            <input 
              type="email" 
              placeholder="Your professional email..."
              className="flex-1 bg-paper/5 border border-paper/10 rounded-3xl px-8 py-6 text-lg focus:outline-none focus:ring-4 focus:ring-paper/10 focus:border-paper/40 transition-all placeholder:text-paper/20"
            />
            <button className="bg-paper text-ink px-12 py-6 rounded-3xl font-bold text-[12px] uppercase tracking-[0.25em] hover:scale-105 transition-all active:scale-95 whitespace-nowrap shadow-2xl">
              Stay Synced
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
