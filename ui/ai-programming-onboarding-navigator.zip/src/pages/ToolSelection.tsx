import { motion } from 'motion/react';
import { TOOLS } from '../constants';
import { Check, Info, ArrowRight, Zap, Target, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function ToolSelection() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-7xl mx-auto px-10 py-48"
    >
      <header className="mb-48 max-w-3xl">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-[1px] bg-sage" />
          <span className="tertiary-text !tracking-[0.3em] !text-sage">Comparative Analysis</span>
        </div>
        <h1 className="text-6xl font-serif tracking-tighter mb-8 text-ink leading-none">抉择的秩序：<br/><span className="opacity-40 italic">找到你的支点</span></h1>
        <p className="text-xl text-sage/70 leading-relaxed font-serif italic border-l-2 border-clay/40 pl-8">
          在工具爆发的当下，克制比尝试更重要。我们衡量了网络延迟、上下文深度与学生预算，为你筛选出最具生命力的两条路径。
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
        {TOOLS.map((tool) => (
          <div key={tool.id} className="step-card flex flex-col group relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-sage/5 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
            
            <div className="p-4 flex-1 relative z-10">
              <div className="flex items-center justify-between mb-16">
                <div className="w-16 h-16 bg-paper rounded-[24px] border border-clay/40 flex items-center justify-center shadow-sm group-hover:bg-ink group-hover:text-paper transition-all duration-700">
                  {tool.id === 'claude-code' ? <Zap size={24} /> : <Target size={24} />}
                </div>
                <div className="flex items-center gap-3">
                   <div className="w-2 h-2 rounded-full bg-clay animate-pulse" />
                   <span className="tertiary-text opacity-40 uppercase">System Node</span>
                </div>
              </div>
              
              <h2 className="text-4xl font-serif font-bold tracking-tight mb-6 text-ink group-hover:opacity-60 transition-opacity">{tool.name}</h2>
              <p className="text-lg text-sage/70 mb-16 leading-relaxed font-medium max-w-sm">{tool.description}</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-16 border-t border-clay/20 pt-16">
                <div>
                  <h4 className="tertiary-text mb-8 !text-ink/80">设计优势</h4>
                  <ul className="space-y-6">
                    {tool.pros.map(pro => (
                      <li key={pro} className="flex items-start gap-4 text-[14px] leading-snug">
                        <Check size={16} className="text-sage mt-1 flex-shrink-0" />
                        <span className="text-sage/90 font-medium font-serif italic">{pro}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h4 className="tertiary-text mb-8 !text-ink/80">适配卡点</h4>
                  <ul className="space-y-6">
                    {tool.cons.map(con => (
                      <li key={con} className="flex items-start gap-4 text-[14px] leading-snug">
                        <Info size={16} className="text-clay mt-1 flex-shrink-0" />
                        <span className="text-sage/50 italic font-medium">{con}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            <div className="mt-16 pt-16 border-t border-clay/20 bg-oat/5 -mx-12 -mb-12 px-12 pb-12 rounded-b-[40px] relative z-10">
              <div className="flex flex-wrap gap-3 mb-16">
                {tool.scenarios.map(s => (
                  <span key={s} className="bg-paper border border-clay/60 px-5 py-2.5 rounded-full text-[11px] font-black uppercase tracking-[0.2em] text-sage/60 shadow-sm transition-all hover:bg-white hover:text-ink hover:border-ink">
                    {s}
                  </span>
                ))}
              </div>
              
              <div className="flex flex-col gap-10">
                <p className="text-[15px] leading-relaxed text-sage/60 font-serif italic border-l-2 border-clay pl-8 max-w-md">
                  “{tool.recommendation}”
                </p>
                <Link to="/setup" className="btn-claude w-fit">
                  开始配置流程 <ArrowRight size={18} />
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Advisory Section */}
      <div className="mt-48 p-24 rounded-[64px] bg-ink text-paper relative overflow-hidden flex flex-col lg:flex-row items-center gap-24">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(107,112,92,0.15),transparent)] opacity-50" />
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-clay/5 rounded-full blur-[140px] -translate-y-1/2 translate-x-1/4" />
        
        <div className="relative z-10 p-10 bg-paper/5 rounded-3xl border border-paper/10 backdrop-blur-sm">
          <BookOpen size={48} className="text-clay" />
        </div>
        
        <div className="relative z-10 flex-1 text-center lg:text-left">
          <h3 className="font-serif text-4xl mb-6 italic opacity-90">追求长期价值的建议</h3>
          <p className="text-xl text-paper/50 leading-relaxed max-w-2xl font-serif italic mb-0">
            校内开发者应优先关注 <b>GitHub Student Developer Pack</b>。它不仅是免费 Copilot 的门票，更是一个包含数千美金真实价值的工具包。
          </p>
        </div>
        
        <button className="relative z-10 bg-paper text-ink px-16 py-6 rounded-full font-bold text-[12px] uppercase tracking-[0.2em] hover:scale-105 transition-all shadow-2xl active:scale-95 whitespace-nowrap">
          获取申请指引
        </button>
      </div>
    </motion.div>
  );
}
