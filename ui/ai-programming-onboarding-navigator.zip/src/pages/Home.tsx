import { motion } from 'motion/react';
import { ROADMAP_NODES } from '../constants';
import { ArrowRight, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -30 }}
      className="max-w-6xl mx-auto px-10 py-48"
    >
      <header className="mb-64 text-center relative">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-sage/5 rounded-full blur-[160px] pointer-events-none" />
        
        <div className="inline-flex items-center gap-4 px-6 py-2.5 rounded-full bg-oat/50 border border-clay/40 mb-16 shadow-sm relative z-10 transition-all hover:bg-white hover:scale-105 cursor-default">
          <div className="w-2.5 h-2.5 rounded-full bg-sage animate-pulse" />
          <span className="tertiary-text !text-sage !tracking-[0.3em]">Architectural Onboarding • v1.0</span>
        </div>
        
        <h1 className="text-7xl md:text-9xl font-serif tracking-tighter mb-16 leading-[0.95] text-ink relative z-10">
          极简，亦是<br/>
          <span className="italic opacity-20 hover:opacity-40 transition-opacity">最高的效率</span>
        </h1>
        
        <p className="text-2xl text-sage/60 max-w-2xl mx-auto leading-relaxed font-serif italic relative z-10">
          “消除安装与配置的龃龉，让思考重新回到逻辑本身。”
        </p>
      </header>

      <div className="relative">
        <div className="absolute left-[63px] top-16 bottom-16 w-px bg-clay/30" />

        <div className="space-y-48 relative z-10">
          {ROADMAP_NODES.map((node, index) => (
            <motion.div 
              key={node.id}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-150px" }}
              transition={{ delay: index * 0.1, duration: 1.5, ease: [0.23, 1, 0.32, 1] }}
              className="flex gap-24 group"
            >
              {/* Node Indicator with Tension */}
              <div className="relative flex-shrink-0">
                <div className="w-32 flex justify-center pt-3">
                  <div className="w-16 h-16 rounded-full border border-clay/60 bg-paper flex items-center justify-center transition-all duration-1000 group-hover:bg-ink group-hover:border-ink group-hover:scale-110 shadow-sm relative z-20 overflow-hidden">
                    <span className="text-lg font-serif font-bold text-sage/40 group-hover:text-paper">{index + 1}</span>
                    <div className="absolute inset-0 bg-gradient-to-tr from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  {/* Subtle Diffusion */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-sage/5 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-all duration-1000" />
                </div>
              </div>

              {/* Node Content with Suspension */}
              <div className="flex-1 step-card group-hover:border-clay/80 group-hover:shadow-[0_60px_120px_-30px_rgba(0,0,0,0.08)]">
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-12 mb-12">
                  <div className="max-w-3xl">
                    <div className="flex items-center gap-8 mb-6">
                      <h3 className="text-4xl md:text-5xl font-serif font-bold tracking-tight text-ink group-hover:opacity-50 transition-opacity leading-none">{node.title}</h3>
                      {node.commonPitfalls > 0 && (
                        <div className="flex items-center gap-3 px-4 py-1.5 rounded-full bg-clay/20 text-sage/80 border border-clay/10">
                          <AlertCircle size={16} />
                          <span className="text-[11px] font-black uppercase tracking-[0.3em] leading-none whitespace-nowrap">{node.commonPitfalls} BOTTLENECKS</span>
                        </div>
                      )}
                    </div>
                    <p className="text-[20px] text-sage/70 leading-relaxed font-medium font-serif italic border-l-2 border-clay/40 pl-8 py-1">
                      {node.description}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-5 mb-20">
                  {node.tasks.map(task => (
                    <div key={task} className="flex items-center gap-3.5 px-6 py-3 rounded-2xl bg-oat/20 border border-clay/10 transition-all hover:bg-clay/30 hover:scale-105">
                      <div className="w-2 h-2 rounded-full bg-sage/30" />
                      <span className="text-[12px] font-black text-sage/80 uppercase tracking-[0.3em]">{task}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-12 border-t border-clay/30 flex flex-col lg:flex-row items-center justify-between gap-12">
                  <Link 
                    to={node.id === 'select-tool' ? '/tools' : node.id === 'install-tool' ? '/setup' : '/'} 
                    className="link-claude text-sm"
                  >
                    Explore Documentation 
                    <ArrowRight size={16} className="transition-transform group-hover:translate-x-3" />
                  </Link>
                  <div className="flex items-center gap-6">
                    <button className="h-14 px-10 rounded-full text-[12px] font-black uppercase tracking-[0.2em] border border-clay text-sage/40 hover:border-ink hover:text-ink transition-all active:scale-95 bg-transparent">
                      Acknowledge
                    </button>
                    <Link 
                      to={`/troubleshooting?category=${node.id === 'config-network' ? 'network' : node.id === 'install-tool' ? 'npm' : 'env'}`}
                      className="h-14 px-10 rounded-full text-[12px] font-black uppercase tracking-[0.2em] bg-clay/30 text-sage border border-clay/20 hover:bg-clay/50 transition-all flex items-center active:scale-95"
                    >
                      Antidote
                    </Link>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Philosophy Section */}
      <div className="mt-64 grid grid-cols-1 md:grid-cols-2 gap-32 border-t border-clay/50 pt-32 pb-64">
        <div className="space-y-12">
          <div className="flex items-center gap-4">
            <div className="w-12 h-[1px] bg-sage/40" />
            <h4 className="tertiary-text !text-sage/40">Our Philosophy</h4>
          </div>
          <p className="text-4xl font-serif italic text-ink leading-tight">
            “真正的效率不仅仅是速度，而是对环境的深刻理解。”
          </p>
          <p className="text-lg text-sage/60 leading-relaxed max-w-sm font-medium">
            官方文档往往假设用户具有全局网络环境和完美的环境配置。我们致力于填补现实骨感与理想丰满之间的空白。
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-16">
          <div className="space-y-8">
            <div className="w-10 h-10 rounded-full bg-oat border border-clay/50 flex items-center justify-center">
               <span className="text-xs font-bold">01</span>
            </div>
            <span className="text-sm font-black uppercase tracking-[0.3em] text-ink">100% 实测</span>
            <p className="text-[13px] text-sage/60 leading-relaxed font-medium">所有解决方案均经过校内多款网络环境实测，排除所有虚头巴脑的描述。</p>
          </div>
          <div className="space-y-8">
            <div className="w-10 h-10 rounded-full bg-oat border border-clay/50 flex items-center justify-center">
               <span className="text-xs font-bold">02</span>
            </div>
            <span className="text-sm font-black uppercase tracking-[0.3em] text-ink">Zero Noise</span>
            <p className="text-[13px] text-sage/60 leading-relaxed font-medium">拒绝营销术语与算法焦虑，只提供最通缩、最直接的上手路径。</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
