/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Network, 
  Settings, 
  Terminal, 
  ArrowRight, 
  Compass, 
  CheckCircle2, 
  AlertCircle,
  HelpCircle,
  FileCode,
  Github,
  Zap
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

import Home from './pages/Home';
import ToolSelection from './pages/ToolSelection';
import SetupVerification from './pages/SetupVerification';
import Troubleshooting from './pages/Troubleshooting';
import FirstTask from './pages/FirstTask';
import Updates from './pages/Updates';

/** Utility for Tailwind class merging */
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

function NavItem({ to, label, icon: Icon }: { to: string; label: string; icon: any }) {
  const location = useLocation();
  const isActive = location.pathname === to;

  return (
    <Link 
      to={to} 
      className={cn(
        "relative flex items-center gap-2 px-6 py-2 text-[12px] font-bold uppercase tracking-widest transition-all rounded-full group",
        isActive 
          ? "text-ink" 
          : "text-sage/60 hover:text-ink"
      )}
    >
      <Icon size={14} className={cn("transition-colors", isActive ? "text-ink" : "text-sage/40 group-hover:text-sage")} />
      <span>{label}</span>
      {isActive && (
        <motion.div 
          layoutId="nav-glow"
          className="absolute inset-0 bg-clay/30 rounded-full -z-10"
          transition={{ type: 'spring', bounce: 0.1, duration: 0.8 }}
        />
      )}
    </Link>
  );
}

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col technical-grid">
      {/* Top Navigation */}
      <header className="sticky top-0 z-50 bg-paper/80 backdrop-blur-xl border-b border-clay/30">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-4 group">
            <div className="w-8 h-8 rounded-full bg-ink flex items-center justify-center transition-transform group-hover:rotate-12">
              <Compass size={18} className="text-paper" />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-serif font-bold tracking-tight leading-none mb-0.5 text-ink">AI Navigator</span>
              <span className="tertiary-text opacity-50">Thoughtful Onboarding</span>
            </div>
          </Link>

          <nav className="hidden xl:flex items-center gap-2">
            <NavItem to="/" label="指南路径" icon={Compass} />
            <NavItem to="/tools" label="选择工具" icon={Settings} />
            <NavItem to="/setup" label="环境配置" icon={Terminal} />
            <NavItem to="/troubleshooting" label="对策索引" icon={AlertCircle} />
            <NavItem to="/practice" label="实践案例" icon={FileCode} />
            <NavItem to="/updates" label="情报动态" icon={Network} />
          </nav>

          <div className="flex items-center gap-4">
            <div className="h-6 w-px bg-clay/50 hidden md:block" />
            <a 
              href="https://github.com" 
              target="_blank" 
              rel="noreferrer"
              className="p-2 text-sage/40 hover:text-ink transition-colors"
            >
              <Github size={18} />
            </a>
            <button className="h-10 px-6 rounded-full bg-ink text-paper text-[10px] font-black uppercase tracking-[0.1em] hover:opacity-90 transition-all active:scale-95 shadow-xl shadow-clay/20">
              获取校园包
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 relative">
        <AnimatePresence mode="wait">
          {children}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="border-t border-clay/30 py-24 px-6 bg-oat/20">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-20">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 font-serif font-bold text-lg mb-8 text-ink">
              <Compass size={20} className="text-sage" />
              <span>AI Onboarding Navigator</span>
            </div>
            <p className="text-[15px] text-sage/70 leading-relaxed max-w-sm mb-10 font-medium">
              这是一个由开发者发起的开源文档站，旨在为中国大学生提供最真实、最高效的 AI 编程入门指南。消除环境焦虑，专注逻辑实现。
            </p>
            <div className="flex items-center gap-4 py-2 px-4 rounded-full bg-paper w-fit border border-clay/30">
              <span className="h-1.5 w-1.5 rounded-full bg-sage animate-pulse" />
              <span className="text-[10px] font-black uppercase tracking-widest text-sage/60">Systems Active & Reasoning</span>
            </div>
          </div>
          
          <div className="flex flex-col gap-6">
            <span className="tertiary-text">探索</span>
            <div className="flex flex-col gap-4">
              <Link to="/tools" className="text-sm text-sage/80 hover:text-ink transition-colors font-medium">决策矩阵</Link>
              <Link to="/setup" className="text-sm text-sage/80 hover:text-ink transition-colors font-medium">环境诊断</Link>
              <Link to="/troubleshooting" className="text-sm text-sage/80 hover:text-ink transition-colors font-medium">对策搜索</Link>
            </div>
          </div>

          <div className="flex flex-col gap-6">
            <span className="tertiary-text">外链</span>
            <div className="flex flex-col gap-4">
              <a href="#" className="text-sm text-sage/80 hover:text-ink transition-colors font-medium">Claude.ai</a>
              <a href="#" className="text-sm text-sage/80 hover:text-ink transition-colors font-medium">Github Student Pack</a>
              <a href="#" className="text-sm text-sage/80 hover:text-ink transition-colors font-medium">参与贡献</a>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-24 pt-10 border-t border-clay/30 flex flex-col sm:flex-row justify-between items-center gap-6">
          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-sage/40">© 2026 AI ONBOARDING STATION / AUTHORED BY CLAUDE-STYLE DESIGN</p>
          <div className="flex gap-8">
            <span className="text-[10px] text-sage/40 font-black uppercase tracking-widest cursor-pointer hover:text-ink transition-colors">Privacy</span>
            <span className="text-[10px] text-sage/40 font-black uppercase tracking-widest cursor-pointer hover:text-ink transition-colors">Integrity</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/tools" element={<ToolSelection />} />
          <Route path="/setup" element={<SetupVerification />} />
          <Route path="/troubleshooting" element={<Troubleshooting />} />
          <Route path="/practice" element={<FirstTask />} />
          <Route path="/updates" element={<Updates />} />
        </Routes>
      </Layout>
    </Router>
  );
}
