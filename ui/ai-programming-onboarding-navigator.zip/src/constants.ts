/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type OS = 'windows' | 'macos';

export type NodeStatus = 'not-started' | 'in-progress' | 'completed' | 'stuck';

export interface RoadmapNode {
  id: string;
  title: string;
  description: string;
  nextStepId?: string;
  blockedBy?: string[];
  tasks: string[];
  commonPitfalls: number;
}

export const ROADMAP_NODES: RoadmapNode[] = [
  {
    id: 'select-tool',
    title: '选择工具',
    description: '对比 Claude Code 和 Codex，根据你的场景做决定',
    nextStepId: 'check-env',
    tasks: ['完成工具对比', '确认推荐路径'],
    commonPitfalls: 0,
  },
  {
    id: 'check-env',
    title: '检查电脑环境',
    description: '确认 Node.js, Git 和终端环境是否就绪',
    nextStepId: 'install-tool',
    tasks: ['检查 Node.js', '检查 Git', '确认终端权限'],
    commonPitfalls: 3,
  },
  {
    id: 'install-tool',
    title: '安装工具',
    description: '按照你选择的工具进行针对性安装',
    nextStepId: 'auth',
    tasks: ['执行安装命令', '配置环境变量'],
    commonPitfalls: 5,
  },
  {
    id: 'auth',
    title: '登录与授权',
    description: '关联你的账号或配置 API Key',
    nextStepId: 'config-network',
    tasks: ['完成登录', '授权访问'],
    commonPitfalls: 2,
  },
  {
    id: 'config-network',
    title: '订阅 / API / 网络配置',
    description: '处理网络环境和配额问题',
    nextStepId: 'create-project',
    tasks: ['配置代理/镜像', '检查配额'],
    commonPitfalls: 4,
  },
  {
    id: 'create-project',
    title: '创建测试项目',
    description: '初始化一个干净的工作区',
    nextStepId: 'task-one',
    tasks: ['创建目录', '配置规则文件'],
    commonPitfalls: 1,
  },
  {
    id: 'task-one',
    title: '完成第一次任务',
    description: '跑通一个最小可行闭环',
    tasks: ['执行指令', '完成验证'],
    commonPitfalls: 0,
  }
];

export interface ToolOption {
  id: string;
  name: string;
  description: string;
  pros: string[];
  cons: string[];
  recommendation: string;
  scenarios: string[];
}

export const TOOLS: ToolOption[] = [
  {
    id: 'claude-code',
    name: 'Claude Code',
    description: 'Anthropic 官方推出的终端 AI 编程智能体',
    pros: ['原生支持 agentic 工作流', '出色的推理能力', '简单易用的指令'],
    cons: ['对网络环境要求极高', '目前处于预览版', '需订阅 Claude Pro 或有 API'],
    recommendation: '适合想要全自动解决复杂重构任务，且已有 Claude 账户的学生。',
    scenarios: ['我更想用脚本/终端', '我需要处理跨文件逻辑'],
  },
  {
    id: 'codex',
    name: 'Codex / GitHub Copilot',
    description: '基于 IDE 的最强续写与辅助工具',
    pros: ['IDE 集成极佳', '学生免费（GitHub 学生包）', '生态极其丰富'],
    cons: ['相对较难处理大规模自动任务', '需要申请学生包'],
    recommendation: '适合初学者，想在 IDE 里有顺滑体验，且关注稳定性的学生。',
    scenarios: ['我主要想写课程项目', '我想在 VS Code 里用'],
  }
];

export interface TroubleshootingItem {
  id: string;
  category: 'network' | 'auth' | 'env' | 'npm' | 'permission';
  os: 'all' | 'windows' | 'macos';
  symptom: string;
  cause: string;
  solution: string[];
  provenance: 'official' | 'community' | 'personal';
}

export const TROUBLESHOOTING_DATA: TroubleshootingItem[] = [
  {
    id: 'npm-error-403',
    category: 'npm',
    os: 'all',
    symptom: 'npm install 报错 E403 Forbidden',
    cause: '网络限制或选错了错误的 registry。',
    solution: [
      '尝试切换为淘宝镜像：npm config set registry https://registry.npmmirror.com',
      '检查是否开启了代理工具，并配置 npm proxy。'
    ],
    provenance: 'community'
  },
  {
    id: 'win-ps-permission',
    category: 'permission',
    os: 'windows',
    symptom: '无法加载文件 xxx.ps1，因为在此系统上禁止运行脚本',
    cause: 'PowerShell 默认执行策略限制。',
    solution: [
      '以管理员身份运行 PowerShell',
      '执行 Set-ExecutionPolicy RemoteSigned'
    ],
    provenance: 'official'
  },
  {
    id: 'proxy-claude',
    category: 'network',
    os: 'all',
    symptom: 'Claude Code 无法连接服务器',
    cause: '终端环境未完全继承系统代理。',
    solution: [
      '在终端手动 export https_proxy=http://... (mac)',
      '或者 $env:https_proxy="http://..." (Windows)'
    ],
    provenance: 'personal'
  }
];
